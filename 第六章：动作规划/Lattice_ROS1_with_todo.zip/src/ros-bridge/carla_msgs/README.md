# ros-carla-msgs
Official ROS messages for CARLA.

Use them in conjunction with [CARLA ROS bridge](https://github.com/carla-simulator/ros-bridge).
